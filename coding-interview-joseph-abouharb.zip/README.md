# SVG generator - Vue Application

## Instructions

1. npm install
2. npm run start

## Features
Features an SVG Creator tool that can
- Draw Rectangles with the r command
- Draw Circles with the c command
- Draw Polygons with the p command
- Draw Text **(bonus)** *`t x-position y-position text`*

Each Drawing comes with unique and random styling.