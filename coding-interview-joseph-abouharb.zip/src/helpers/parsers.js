import Attrs from './locals';
import Error from './errors';

export const parser = (input) => {
  const text = input.toLowerCase().trim();
  if (!text) {
    return Error.NoInputEntered;
  }
  const [type, ...params] = text.split(' ');
  const shape = Attrs[type];
  if (!shape) {
    return Error.IncorrectShape;
  }
  if (!shape.isValidLength(params.length)) {
    return Error.InsufficientParamaters(shape)
  }
  if (!shape.isValidAttrs(params)) {
    return Error.Malformed(shape);
  }
  return [shape, params];
}

export const getParams = (shape, params) => {
  if (shape.type === 'Coordinate') {
    params = [params.join(' ')]
  }

  const attrs = shape.attrs.reduce((obj, value, index) => {
    return [ ...obj, `${value}="${params[index]}"` ]
  }, [])
  const props = shape.props.length ? shape.getPropsFrom(params) : [];
  return [attrs, props];
}

export const getSvgStyle = (  ) => {
  const genColor = () => {
    const RGBlist = Array.from({ length: 3}, (v,k) => {
    const random = Math.floor(Math.random() * 256);
    return random
    });
    return `rgb(${RGBlist.join(", ")})`
  };
  const generateStrokeWidth = () => Math.floor(Math.random() * 10).toString();
  const generateOpacity = () => Math.random(Math.random()).toString(); 

  return [
    `fill:${genColor()};`,
    `stroke:${genColor()};`,
    `stroke-width;${generateStrokeWidth()};`,
    `fill-opacity:${generateOpacity()};`,
    `stroke-opacity:${generateOpacity()};`,
  ]
}