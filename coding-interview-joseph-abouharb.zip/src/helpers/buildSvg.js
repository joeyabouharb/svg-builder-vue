import { parser, getParams, getSvgStyle } from './parsers';

const buildSvg = (text) => new Promise ((resolve, reject) => {
  const lines = text.split('\n');
  const results = lines.map((line, lineNumber) => {
    const result = parser(line);
    if (result.error) {
      reject({ ...result, lineNumber: lineNumber + 1 });
    }
    const [shape, params] = result;
    const [parameters, props] = getParams(shape, params);
    const style = getSvgStyle().join(' ');
    const attrs = parameters.join(' ');
    const res = props.length
    ? `
        <${shape.name} ${attrs} style="${style}">${props}</${shape.name}>
      `
    : `
    <${shape.name} ${attrs} style="${style}"/>
    `
    return res;
  });
  resolve(results.join(""))
})

export default buildSvg;