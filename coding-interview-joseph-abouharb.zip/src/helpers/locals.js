const coordTest = /^[0-9]+,[0-9]+$/
const Attrs = {
  c: {
    name: "circle",
    attrs: ['cx', 'cy', 'r'],
    constraint: '3',
    props: [],
    type: 'Number',
    isValidLength: (length) => length === 3,
    isValidAttrs: (params) => params.every(
        (value) => !Object.is(Number(value), NaN)
      ),
  },
  r: {
    name: "rect",
    attrs: ['x', 'y', 'width', 'height'],
    props: [],
    constraint: '4',
    type: 'Number',
    isValidLength: (length) => length === 4,
    isValidAttrs: (params) => params.every(
      (value) => !Object.is(Number(value), NaN)
    ),
  },
  p: {
    name: 'polygon',
    attrs: ['points'],
    constraint: '3 or more',
    type: 'Coordinate',
    props: [],
    isValidLength: (length) => length > 2,
    isValidAttrs: (params) => params.every(
      (value) => coordTest.test(value)
    ),
  },
  t: {
    name: "text",
    attrs: ['x', 'y'],
    constraint: "3 or more",
    type: 'Number',
    props: ['text'],
    isValidLength: (length) => length > 2,
    isValidAttrs: function (params) {
      const attrs = params.slice(1, this.attrs.length);
      return attrs.every(
        (value) => !Object.is(Number(value), NaN)
      );
    },
    getPropsFrom: function (params) {
      const props = params.slice(this.attrs.length);
      return props.join(" ").trim();
    }
  }
};

export default Attrs;
