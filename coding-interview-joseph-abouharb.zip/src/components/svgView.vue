<template>
    <div class="svg-view">
      <figure class="centered">
        <h2 class="center-text">Result:</h2>
          <svg
            version="1.1"
            width="250px"
            height="250px"
            xmlns="http://www.w3.org/2000/svg"
            style="border: solid 1px; margin-top: 1rem;"
            v-html="drawing"
          >
          </svg>
      </figure>
    </div>
</template>

<script>
import Vue from 'vue';
export default Vue.extend({
  name: 'SvgView',
  props: {
    drawing: {
      type: String,
    },
  },
});
</script>

<style>
.svg-view {
  margin: 0.5rem;
  display: flex;
  flex-direction: column;
  flex-grow: 1;
}
.centered {
  display: flex;
  flex-direction: column;
  align-items: center;
  flex-grow: 1;
  background-color: white;
  margin: 0.5rem;
  padding: 0.5rem;
  border-radius: 10px;
  -webkit-box-shadow: -11px 12px 22px -7px rgba(87,64,64,1);
  -moz-box-shadow: -11px 12px 22px -7px rgba(87,64,64,1);
  box-shadow: -11px 12px 22px -7px rgba(87,64,64,1);
}
</style>